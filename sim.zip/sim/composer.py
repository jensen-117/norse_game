"""The encounter composer: fills a slot budget from a tagged catalog of enemies.

How a pack is rolled (Joseph's d3 machine, generalised):
  1. Gates narrow the catalog: family, element, school, rank, art-only, or any tag. A biome is just a
     named gate ("Eldhall": elements Eld and Reyk).
  2. While budget remains: list the costs (1, 2, 3) that still FIT -- cost <= remaining budget, a unit
     of that cost survives the gates, the rules allow it, and what would be left can still be filled
     exactly. Roll among those costs (the d3, with any impossible faces removed). Then pick a unit of
     that cost from the gated catalog (weighted).
  3. Rules are toggles: banned costs ("no 1-costs"), per-cost caps ("only one 3-cost"), a unit cap
     (never more than the 6 board cells), family minimums/maximums, per-family weights.
  4. Placement: front-liners (Mogel) take the Front row, casters (Ande) the Rear; overflow spills to
     the other row. Cells are 3 lanes x (Front, Rear).
Rolling the COST first and the unit second keeps big units appearing even when the gated pool holds
many small ones; rolling units directly would drown the 3-costs.
"""
import random
from functools import lru_cache
from data import SPIRIT_RANKS, MOGEL_RANKS, SCHOOL_OF

# ---------------------------------------------------------------- catalog
ELEMENTS = ["Eld", "Reyk", "Vatn", "Hrim", "Blast", "Blixt", "Jord", "Gro", "Sol", "Lak", "Natt", "Aska"]
ART = {("Ande", "Halv"), ("Ande", "Ande"), ("Mogel", "Halv"), ("Mogel", "Litel"), ("Mogel", "Mogel")}
ROLE = {"Ande": "rear", "Mogel": "front"}

def catalog():
    out = []
    for fam, ranks in (("Ande", SPIRIT_RANKS), ("Mogel", MOGEL_RANKS)):
        for rank, r in ranks:
            for el in ELEMENTS:
                out.append(dict(family=fam, rank=rank, element=el, school=SCHOOL_OF[el], cost=r["cost"],
                                role=ROLE[fam], art=(fam, rank) in ART, weight=1.0))
    return out

BIOMES = {   # a biome is a named gate; elements come in school pairs, plus a neighbour now and then
    "Eldhall":   dict(element=["Eld", "Reyk"]),
    "Vatnhall":  dict(element=["Vatn", "Hrim"]),
    "Blasthall": dict(element=["Blast", "Blixt"]),
    "Jordhall":  dict(element=["Jord", "Gro"]),
    "Solhall":   dict(element=["Sol", "Lak"]),
    "Natthall":  dict(element=["Natt", "Aska"]),
    "Mire":      dict(element=["Jord", "Gro", "Vatn"]),          # mould country: Mogel heavy
    "Ashfield":  dict(element=["Eld", "Reyk", "Aska"]),
}

def roll_biome(rng, names=None):
    """The freeform roll: pick a biome, which is just a named element gate."""
    name = rng.choice(names or list(BIOMES))
    return name, dict(BIOMES[name])

# ---------------------------------------------------------------- gates and rules
def gate(cat, **g):
    """Keep entries whose field is in the given list (or equals the value). art_only=True keeps drawn units."""
    out = []
    for e in cat:
        if g.get("art_only") and not e["art"]: continue
        ok = True
        for k, v in g.items():
            if k == "art_only": continue
            vals = v if isinstance(v, (list, tuple, set)) else [v]
            if e.get(k) not in vals: ok = False; break
        if ok: out.append(e)
    return out

DEFAULT_RULES = dict(budget=6, max_units=6, banned_costs=(), cost_caps={}, family_max={}, family_min={},
                     family_weight={})

def _fillable(remaining, costs, caps, units_left):
    """Can `remaining` be met exactly with the allowed costs, the caps and the unit limit?"""
    costs = tuple(sorted(costs)); caps = tuple(sorted(caps.items()))
    return _fill(remaining, costs, caps, units_left)

@lru_cache(maxsize=None)
def _fill(remaining, costs, caps, units_left):
    if remaining == 0: return True
    if units_left <= 0: return False
    capd = dict(caps)
    for c in costs:
        if c > remaining or capd.get(c, 99) <= 0: continue
        nxt = dict(capd)
        if c in nxt: nxt[c] -= 1
        if _fill(remaining - c, costs, tuple(sorted(nxt.items())), units_left - 1): return True
    return False

class CompositionError(Exception): pass

def compose(rng, pool, rules=None, log=None):
    """Roll one pack. Returns a list of catalog entries, in roll order."""
    R = dict(DEFAULT_RULES); R.update(rules or {})
    caps = dict(R["cost_caps"])
    fam_count = {}
    picks, remaining = [], R["budget"]
    def live_pool():
        p = []
        for e in pool:
            if e["cost"] in R["banned_costs"]: continue
            if fam_count.get(e["family"], 0) >= R["family_max"].get(e["family"], 99): continue
            p.append(e)
        return p
    def need_min():   # families still short of their minimum must be picked first
        return [f for f, m in R["family_min"].items() if fam_count.get(f, 0) < m]
    while remaining > 0:
        p = live_pool()
        short = need_min()
        if short: p = [e for e in p if e["family"] in short] or p
        units_left = R["max_units"] - len(picks)
        avail = {e["cost"] for e in p}
        faces = []
        for c in (1, 2, 3):
            if c not in avail or c > remaining or caps.get(c, 99) <= 0: continue
            after = dict(caps)
            if c in after: after[c] -= 1
            all_costs = {e["cost"] for e in live_pool()}
            if _fillable(remaining - c, all_costs, after, units_left - 1): faces.append(c)
        if not faces:
            raise CompositionError(f"cannot fill {remaining} more slots with {sorted(avail)} under {R}")
        c = rng.choice(faces)
        if log is not None: log.append(f"left {remaining}: faces {faces} -> rolled {c}")
        cands = [e for e in p if e["cost"] == c]
        w = [e["weight"] * R["family_weight"].get(e["family"], 1.0) for e in cands]
        e = rng.choices(cands, weights=w)[0]
        picks.append(e); remaining -= c
        fam_count[e["family"]] = fam_count.get(e["family"], 0) + 1
        if c in caps: caps[c] -= 1
    return picks

def place(picks):
    """Assign cells: 3 lanes x (Front, Rear). Front-liners fill Front first, casters fill Rear first."""
    cells = {"front": [], "rear": []}
    order = sorted(picks, key=lambda e: -e["cost"])       # big units get first choice of lane
    for e in order:
        want = e["role"]; other = "rear" if want == "front" else "front"
        (cells[want] if len(cells[want]) < 3 else cells[other]).append(e)
    if len(cells["front"]) == 0 and cells["rear"]:         # nobody may hide behind an empty Front
        cells["front"].append(cells["rear"].pop())
    return [(row, lane, e) for row in ("front", "rear") for lane, e in enumerate(cells[row])]

def describe(e):
    from engine import spirit_name, mogel_name
    return spirit_name(e["rank"], e["element"]) if e["family"] == "Ande" else mogel_name(e["rank"], e["element"])

def spawn(placed, level):
    """Turn placed entries into battle units, lettering duplicates (Eldmogel A, Eldmogel B)."""
    from engine import spawn_spirit, spawn_mogel
    units = []
    for row, lane, e in placed:
        u = spawn_spirit(e["rank"], e["element"], level) if e["family"] == "Ande" else spawn_mogel(e["rank"], e["element"], level)
        u.cell = (row, lane); units.append(u)
    seen = {}
    for u in units: seen[u.name] = seen.get(u.name, 0) + 1
    count = {}
    for u in units:
        u.suffix = ""
        if seen[u.name] > 1:
            count[u.name] = count.get(u.name, 0) + 1
            u.suffix = f" {chr(64 + count[u.name])}"; u.name += u.suffix
    return units

if __name__ == "__main__":
    rng = random.Random(7)
    cat = catalog()
    demos = [
        ("Any drawn unit, any element", dict(art_only=True), {}),
        ("Biome Eldhall, drawn units", dict(art_only=True, **BIOMES["Eldhall"]), {}),
        ("Mire, all ranks, only one 3-cost", BIOMES["Mire"], dict(cost_caps={3: 1})),
        ("Vatnhall, no 1-costs", BIOMES["Vatnhall"], dict(banned_costs=(1,))),
        ("Mixed: at least 1 Mogel and 1 Ande, drawn", dict(art_only=True), dict(family_min={"Mogel": 1, "Ande": 1})),
        ("Small fight: budget 3", dict(art_only=True), dict(budget=3)),
    ]
    print("\nFreeform: roll a biome, then fill with drawn units")
    for _ in range(4):
        name, g = roll_biome(rng)
        placed = place(compose(rng, gate(cat, art_only=True, **g)))
        print(f"   {name:<10} " + " | ".join(f"{row[0].upper()}{lane+1} {describe(e)} ({e['cost']})" for row, lane, e in placed))
    for title, g, rules in demos:
        print(f"\n{title}")
        for _ in range(3):
            log = []
            picks = compose(rng, gate(cat, **g), rules, log)
            placed = place(picks)
            print("   " + " | ".join(f"{row[0].upper()}{lane+1} {describe(e)} ({e['cost']})" for row, lane, e in placed)
                  + "      rolls: " + "; ".join(x.split(': ')[1] for x in log))
