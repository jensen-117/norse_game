Art, Resurrect 64 only (every pixel checked)

heroes/wizard_front   Front-facing wizard, 4 frames, six caster classes. Robes step along each school's ramp.
heroes/wizard_side    Side-facing wizard, 3 frames, six caster classes, right- and left-facing.
spirits/halvande      Halvande (16x16), 4 frames, all twelve elements.
spirits/ande          Standard Ande (16x32), 7 frames, all twelve elements.
animals               Cat, snow leopard, howling wolf, rat (4 poses). Original colors snapped to Resurrect 64,
                      each tone kept distinct within its sprite.
backgrounds           The gold Sol watercolor (a painted image, so not palette-limited).
sheets                Contact sheets, before/after comparisons, and animated previews.

heroes/wizard_side_v2 Side wizard v2 (Joseph's sprite, 17 frames), six caster classes, right- and left-facing.
                      Frames: idle1-3, hit, spell1, run1-4, charge1-3, bomb1-2, downed, defend, defend_hit (file names use these labels).
                      Animations (frame labels, ms):
                        idle   idle1 600, idle2 300, idle3 600, idle2 300
                        hit    idle1 100, hit 400, idle1 300
                        spell  idle1 150, spell1 450, idle1 300
                        run    run1-4 at 125ms each (even 8fps)
                        downed idle1 150, hit 200, downed 1200
                        defend idle1 150, defend 1200
                        defend_hit defend 300, defend_hit 350, defend 600
                        taunt  idle1 150, bomb2 650 (the yell), defend 900
                        charge charge1 300, charge2 300, charge3 450 (loops while charging)
                        bomb   bomb1 150, bomb2 500
                        cast   idle1, charge1-3, bomb1-2, idle1 (full sequence)
                                            Face tones: chin shadow and open mouth #966c6c, mouth depth #694f62.
                      frames/ single PNGs, strips/ one strip per animation in play order (Aseprite: File > Import
                      Sprite Sheet, 16x32 cells), gifs/ 8x previews. Robe = base, fold, deep fold per class:
                      Hafrunar 4d9be6/4d65b4/484a77  Brennumar ea4f36/b33831/6e2727  Skurmar c7dcd0/9babb2/7f708a
                      Lundar a2a947/676633/4c3e24  Dagskald f9c22b/f79617/fb6b1d  Seidar 905ea9/6b3e75/45293f

effects               Two battle effects sheets, recolored to Resurrect 64 per element plus a white Martial set.
                        fx_*      fx_source.png, bdragon1727 "Free Effect and Bullet 16x16"
                                  https://bdragon1727.itch.io/free-effect-and-bullet-16x16
                        bullet_*  bullet_source.png, bdragon1727 "Fire Pixel Bullet 16x16"
                                  https://bdragon1727.itch.io/fire-pixel-bullet-16x16
                      bdragon1727 terms (same on both pages): free for non-commercial use; commercial use asks for a contribution of any
                      amount (the author says credit counts); "Modify as desired"; no reselling or redistributing
                      the asset, so keep these sheets out of any public repo.
                      Recolor: the source's warm ramp ranked dark->light onto 5-step ramps. Layout is unchanged, so
                      the same cell is the same effect in every element sheet.

environment           Joseph's wall (22 x 32x32) and floor (3 x 96x96) tiles snapped to Res64 by value:
                      stone onto 3e3546/625565/7f708a/9babb2, reddish mortar onto 2e222f/45293f. Floors sit one
                      step lighter so slabs read as lit board cells. walls/ and floors/ hold single PNGs;
                      *_strip.png import into Aseprite (File > Import Sprite Sheet).

ui                    font_sheet.png: Joseph's bitmap font, 16 columns of 8x16 cells on a 9x17 pitch; rows 0-5 are
                      ASCII, later rows continue from U+00A0 (assumed). Rendered proportionally, 1px spacing.

mocks                 320x180 battle-screen mocks: Neutral, Vatn (Move: open Rear cells lit) and Eld (one enemy cell
                      targeted). Walls and floors take an area stone ramp (all Res64): Neutral cool grey; Vatn blue
                      stone with wet teal seams; Eld warm stone with smouldering red mortar (walls only).
                      Floor = three courses of foreshortened slabs, one per lane, as one continuous grid sheared
                      0.3px per px of depth (all one direction), slabs laid with 1px mortar joints; every board
                      cell is one slab (34px pitch). Cell highlight is always white.
                      Text box: area-tinted watercolor fill, bevelled band, corner studs, rune plaque, Joseph's font.

slimes                Joseph's Mogel slimes at 32, 24, 16 and 8 px (Mogel/Stor/Drott, Litel, Halv, death droplet),
                      11 frames each: idle1, idle2, surprise, breathe1, breathe2, hit1, hit2, withdraw, cast1-3.
                      Source soft-brush colours sorted into six slots by value: outline 2e222f; deep, shadow, body,
                      sheen, specular from a 5-step ramp. Sheen/specular on the left 40% of each row fades into the
                      body (no rim streak). 24 and 32 px: shadow terminator checker-dithered.
                      Native ramp is Jord (4c3e24 676633 a2a947 b2ba90 c7dcd0); every element ramp is applied
                      (Mogel<size>_<Element>_<frame>.png). Animations: idle 0,1 | hit 5,6,0 | defend 0,7 |
                      charge 0,3,4 | cast 8,9,10,0 | surprise 2,0. mogel_<el>_death_chain.gif: 32 > 24 > 16 > droplet.
dressing              Dungeon dressing from Joseph's tileset pack (source and license to confirm before shipping),
                      cut, scaled x0.5 with a box filter, and snapped by material: stone onto the wall slots
                      (3e3546 625565 7f708a 9babb2, so area recolors carry over), wood/cloth onto 694f62 966c6c
                      ab947a, the pack's brown outline onto 2e222f, flame onto f79617 f9c22b fbff86.
                      props/ 34 pieces (windows, banners, lanterns, alcoves, statues, barrels, doors, wall breaches);
                      decals/ cobwebs (x0.75) and cracks (x1) as masks, coloured per area when placed.
                      dressing_library.png names every piece with its size.
                      Light pools are palette-safe: wall stone inside a pool steps one notch up its own ramp,
                      checker-dithered at the rim. Banners take the area's band colours.
                      mocks/dressed_*: Neutral, Vatn (blue webs, teal seams) and Eld (smouldering mortar, hearth).
